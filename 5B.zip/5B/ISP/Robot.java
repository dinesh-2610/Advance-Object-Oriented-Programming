package ISP;

public class Robot implements Worker {
    @Override
    public void work() {
        System.out.println("Robot is working.");
    }
}
