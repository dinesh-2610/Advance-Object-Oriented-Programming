package LSP;

public class Bird {
    public void fly() {
        System.out.println("Bird is flying");
    }
}