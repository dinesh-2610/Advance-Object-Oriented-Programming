
public class Car implements Vehicle {
    @Override
    public String getType() {
        return "Car";
    }
}