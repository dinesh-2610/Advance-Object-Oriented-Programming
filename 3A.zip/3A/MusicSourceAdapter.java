// MusicSourceAdapter.java
public interface MusicSourceAdapter {
    void playMusic();
    void stopMusic();
}
