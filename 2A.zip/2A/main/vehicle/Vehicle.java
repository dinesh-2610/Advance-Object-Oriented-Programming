package main.vehicle;

public interface Vehicle {
    void drive();
}
