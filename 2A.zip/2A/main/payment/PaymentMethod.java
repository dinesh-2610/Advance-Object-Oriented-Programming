package main.payment;

public interface PaymentMethod {
    void processPayment();
}
